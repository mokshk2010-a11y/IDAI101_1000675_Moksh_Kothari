# 💧 WaterBuddy

A polished Streamlit hydration-tracking web application for FA-2 Python Programming.

## Features
- Age-group goal presets and adjustable personal target
- +250 ml, +500 ml, and custom intake logging
- Live total, remaining, percentage, progress bar, and filling water-bottle mascot
- Milestone messages, daily tips, session log, and reset
- Automatic daily reset on a new calendar date while the session is active
- Session-only, privacy-friendly state (no external database)

**Note:** Age-group goal presets are illustrative for this classroom assignment, not clinical hydration advice.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Test calculation logic
```bash
python -m unittest discover -s tests -v
```

## Deploy to Streamlit Community Cloud
1. Create a GitHub repository named `WaterBuddy`.
2. Upload `app.py`, `hydration.py`, `requirements.txt`, `README.md`, and `tests/` to the repository root.
3. Visit https://share.streamlit.io and sign in with GitHub.
4. Choose **Create app** → **Deploy a public app from GitHub** (wording may vary).
5. Select your repository, branch `main`, and entrypoint `app.py`, then deploy.
6. Open the public URL and test age changes, custom goal, logging, milestones, and reset.
7. Submit a Word/PDF document with the FA-1 storyboard link and deployed app URL.

## GitHub collaboration
In repository **Settings → Collaborators**, invite your teammates by GitHub username. Use feature branches and pull requests for reviews; keep `main` deployable. Do not share passwords or tokens. Note: collaborator controls may vary by repository and account.

## Rubric coverage
- **Coding & interaction (10):** widgets, `st.session_state`, age goals, logging, reset, modular Python logic.
- **Calculations & visuals (5):** pure tested calculations, real-time progress, milestone feedback, water bottle mascot.
- **Interface & deployment (5):** responsive Streamlit layout, consistent styling, GitHub/Streamlit deployment setup.

## Limits
Data is stored only in Streamlit session state. It is **not** a durable multi-device history. A browser/session restart can erase progress. Public deployment requires you to authorize GitHub/Streamlit and verify the resulting URL.
