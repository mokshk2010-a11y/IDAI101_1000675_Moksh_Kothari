"""Pure hydration calculations for WaterBuddy.

Goals are illustrative classroom defaults, not individualized medical advice.
"""
from dataclasses import dataclass

AGE_GOALS = {"6–12": 1600, "13–18": 2000, "19–50": 2500, "51–64": 2300, "65+": 2000}


@dataclass(frozen=True)
class Progress:
    consumed: int
    goal: int
    remaining: int
    percentage: float
    completed: bool


def calculate_progress(consumed: int, goal: int) -> Progress:
    if consumed < 0 or goal <= 0:
        raise ValueError("Consumed must be nonnegative and goal must be positive")
    return Progress(consumed, goal, max(goal - consumed, 0), round(consumed / goal * 100, 1), consumed >= goal)


def message_for(percentage: float) -> tuple[str, str]:
    if percentage >= 100:
        return "Goal achieved!", "Amazing work! You've reached your daily target. 🎉"
    if percentage >= 75:
        return "Almost there!", "You're past 75%. Keep up the momentum! 🌊"
    if percentage >= 50:
        return "Halfway hero!", "You've reached 50%. Great progress! ✨"
    if percentage >= 25:
        return "Great start!", "You've crossed 25%. Keep going! 💧"
    return "Every sip counts", "Start with a glass of water and build your progress. 🌱"
