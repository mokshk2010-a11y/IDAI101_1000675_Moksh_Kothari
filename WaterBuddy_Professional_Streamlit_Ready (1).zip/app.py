"""WaterBuddy | Streamlit hydration tracker. Run: streamlit run app.py"""
from datetime import date
import html
import streamlit as st
from hydration import AGE_GOALS, calculate_progress, message_for

st.set_page_config(page_title="WaterBuddy | Daily Hydration", page_icon="💧", layout="wide", initial_sidebar_state="expanded")

st.markdown("""<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Outfit:wght@500;600;700;800&display=swap');
:root{--ink:#15344c;--blue:#087fa5;--aqua:#e8f9fc}
html,body,[class*="css"],.stApp{font-family:'DM Sans',sans-serif}
.stApp{background:linear-gradient(135deg,#f1fbff 0%,#f7fbff 55%,#e8f9f5 100%);color:#173c52}
h1,h2,h3{font-family:'Outfit',sans-serif!important;letter-spacing:-.035em}
.block-container{max-width:1200px;padding-top:2.4rem;padding-bottom:3rem}
[data-testid="stSidebar"]{background:#e9f6fa}
[data-testid="stMetric"]{background:white;border:1px solid #dceef3;padding:18px;border-radius:18px;box-shadow:0 8px 30px #165f7c0a}
[data-testid="stMetricLabel"]{font-weight:700}
.stButton>button[kind="primary"]{background:linear-gradient(100deg,#087da7,#0aa3ac);color:white;border:0;border-radius:12px;font-weight:700;min-height:48px}
.stButton>button{border-radius:12px;min-height:46px;font-weight:700}
.hero{background:linear-gradient(115deg,#074d72,#087d9f 60%,#16b3b0);padding:32px 35px;border-radius:24px;color:white;box-shadow:0 18px 40px #07658722;margin-bottom:22px}
.hero h1{color:white!important;font-size:2.4rem;margin:0 0 8px}
.hero p{color:#e1f9ff;margin:0;font-size:1.04rem}
.eyebrow{font-size:.78rem;text-transform:uppercase;letter-spacing:.18em;font-weight:800;color:#baf3ed;margin-bottom:10px}
.panel{background:#fff;border:1px solid #e0edf2;border-radius:22px;padding:24px;box-shadow:0 8px 25px #175d740b}
.panel h3{margin:0 0 9px;color:#15445c}
.small{font-size:.88rem;color:#56768a}
.bottle-wrap{display:flex;align-items:center;justify-content:center;min-height:265px}
.bottle{height:236px;width:114px;border:6px solid #167b9f;border-radius:23px 23px 30px 30px;position:relative;background:#effaff;overflow:hidden;box-shadow:inset 8px 0 20px #0a73941b,0 13px 22px #0b6d8a20}
.water{position:absolute;bottom:0;left:0;right:0;background:linear-gradient(180deg,#64d5e9,#1596c9);transition:height .55s ease}
.wave{position:absolute;top:-10px;left:-10%;width:120%;height:20px;background:#64d5e9;border-radius:50%}
.bottle-face{position:absolute;top:43%;left:0;width:100%;text-align:center;font-size:29px;z-index:2;color:#064a69}
.bottle-cap{width:66px;height:18px;border-radius:8px 8px 2px 2px;background:#167b9f;margin:0 auto -2px}
.milestone{background:#eaf9f6;border:1px solid #c9eee8;border-radius:15px;padding:18px 20px;color:#175f65;margin:16px 0}
.footer{color:#668696;text-align:center;font-size:.78rem;margin-top:36px}
</style>""", unsafe_allow_html=True)

# Session-scoped storage: no user account or external database required.
today = date.today().isoformat()
if "date" not in st.session_state or st.session_state.date != today:
    st.session_state.date = today
    st.session_state.consumed = 0
    st.session_state.entries = []
if "age" not in st.session_state:
    st.session_state.age = "19–50"
if "goal" not in st.session_state:
    st.session_state.goal = AGE_GOALS[st.session_state.age]

def age_changed():
    st.session_state.goal = AGE_GOALS[st.session_state.age]

def add_water(amount: int):
    if amount > 0:
        st.session_state.consumed += amount
        st.session_state.entries.append(amount)

def reset_day():
    st.session_state.consumed = 0
    st.session_state.entries = []

with st.sidebar:
    st.markdown("## 💧 WaterBuddy")
    st.caption("YOUR HYDRATION SETTINGS")
    st.selectbox("Age group", list(AGE_GOALS), key="age", on_change=age_changed)
    st.caption(f"Illustrative age-group target: **{AGE_GOALS[st.session_state.age]:,} ml**")
    st.number_input("Personal daily goal (ml)", min_value=250, max_value=10000, step=50, key="goal")
    st.divider()
    st.markdown("#### 🌿 Today's hydration tip")
    tips = ["Keep a reusable bottle where you can see it.", "Drink water with meals and throughout the day.", "Hot weather and exercise can change your hydration needs.", "Your thirst and personal health needs matter more than an app's example goal."]
    st.info(tips[date.today().toordinal() % len(tips)])
    st.caption("Goals here are classroom examples, not medical guidance. Needs vary by health, climate and activity.")
    st.divider()
    st.caption("🔒 Session-only data: your log is not sent to a database and may be lost when the session ends.")

st.markdown('<div class="hero"><div class="eyebrow">YOUR DAILY WELLNESS COMPANION</div><h1>Stay refreshed. Stay on track. 💧</h1><p>Build a simple hydration habit, one glass at a time.</p></div>', unsafe_allow_html=True)
progress = calculate_progress(st.session_state.consumed, st.session_state.goal)

m1,m2,m3 = st.columns(3)
m1.metric("💧 Water consumed", f"{progress.consumed:,} ml")
m2.metric("🎯 Remaining to goal", f"{progress.remaining:,} ml")
m3.metric("✨ Goal achieved", f"{progress.percentage:.1f}%")
st.write("")
left,right = st.columns([1.1,1], gap="large")
with left:
    st.subheader("Today's progress")
    st.caption(f"{progress.consumed:,} ml of {progress.goal:,} ml goal")
    st.progress(min(progress.percentage / 100, 1.0), text=f"{progress.percentage:.1f}% complete")
    title, description = message_for(progress.percentage)
    st.markdown(f'<div class="milestone"><strong>{html.escape(title)}</strong><br>{html.escape(description)}</div>', unsafe_allow_html=True)
    st.subheader("Log your water")
    b1,b2 = st.columns(2)
    with b1:
        if st.button("＋ Add 250 ml", type="primary", use_container_width=True):
            add_water(250)
            st.rerun()
    with b2:
        if st.button("＋ Add 500 ml", use_container_width=True):
            add_water(500)
            st.rerun()
    custom = st.number_input("Custom amount (ml)", min_value=50, max_value=3000, step=50, value=200)
    if st.button("Add custom amount", use_container_width=True):
        add_water(int(custom))
        st.rerun()
    if st.button("↺ Reset today's log", use_container_width=True):
        reset_day()
        st.rerun()
with right:
    st.markdown("### Meet Droplet, your water buddy")
    fill = min(progress.percentage, 100)
    face = "😄" if progress.completed else "😊" if fill >= 50 else "🙂"
    st.markdown(f'<div class="panel"><div class="bottle-wrap"><div><div class="bottle-cap"></div><div class="bottle"><div class="water" style="height:{fill:.1f}%"><div class="wave"></div></div><div class="bottle-face">{face}</div></div></div></div><div style="text-align:center;font-weight:700;color:#176581">{fill:.0f}% bottle filled</div><p class="small" style="text-align:center">Your buddy reacts as you reach new milestones.</p></div>', unsafe_allow_html=True)
    st.write("")
    with st.expander("📊 Today's activity", expanded=True):
        st.write(f"**Glasses logged:** {len(st.session_state.entries)}")
        if st.session_state.entries:
            st.write("Recent entries: " + " · ".join(f"{x} ml" for x in st.session_state.entries[-6:]))
        else:
            st.caption("No water logged yet. Add your first glass!")
        st.caption("For a new day, the log resets automatically when the app session remains active across dates.")

st.markdown('<div class="footer">WaterBuddy • Built with Python & Streamlit • Educational hydration tracker</div>', unsafe_allow_html=True)
