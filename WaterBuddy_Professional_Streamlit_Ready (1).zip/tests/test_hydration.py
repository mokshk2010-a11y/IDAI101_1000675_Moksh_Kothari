import unittest
from hydration import calculate_progress, message_for, AGE_GOALS

class TestHydration(unittest.TestCase):
    def test_start(self):
        p = calculate_progress(0, 2500)
        self.assertEqual((p.remaining, p.percentage), (2500, 0))
    def test_halfway(self):
        p = calculate_progress(1250, 2500)
        self.assertEqual((p.remaining, p.percentage), (1250, 50))
        self.assertEqual(message_for(p.percentage)[0], "Halfway hero!")
    def test_over_goal(self):
        p = calculate_progress(3000, 2500)
        self.assertEqual(p.remaining, 0)
        self.assertEqual(p.percentage, 120)
        self.assertTrue(p.completed)
    def test_invalid(self):
        with self.assertRaises(ValueError):
            calculate_progress(100, 0)
    def test_all_age_goals(self):
        self.assertTrue(all(v > 0 for v in AGE_GOALS.values()))

if __name__ == '__main__':
    unittest.main()
